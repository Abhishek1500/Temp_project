### Local setup
 - Clone 
 -  set up virtual env 
 - `pip install -r requirements` to install everything
 - Change the DB URI accordingly and ensure DB schema matches
